var menuStrcture = [
	{
		title: 'Documents',
		icon: 'fa fa-reorder',
		items: [
			{
				name: 'APIs',
				icon: 'fa fa-code',
				link: '#',
				items: [
					{
						title: 'APIs',
						icon: 'fa fa-code',
						items: [
							{
								name: 'Adapter',
								link: '#api-Adapter',
							},
							{
								name: 'Application',
								link: '#api-Application',
							},
							{
								name: 'AudioCapture',
								link: '#api-audiocapture',
							}
						]
					}
				]
			},
			{
				name: 'Guides',
				icon: 'fa fa-book',
				link: '#',
				items: [
					{
						title: 'Guides',
						icon: 'fa fa-book',
						items: [
							{
								name: 'About',
								link: '#guide-about',
							},
							{
								name: 'Setup',
								link: '#guide-setup',
							},
							{
								name: 'Tutorial',
								link: '#guide-tutdatacaptureprofile',
							}
						]
					}
				]
			},
			
		]
	}
];